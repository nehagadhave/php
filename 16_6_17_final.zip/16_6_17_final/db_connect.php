<?php
     define('HOST','mysql.hostinger.in');
	define('USER','u312413986_admin');
	define('PASS','admin123');
	define('DB','u312413986_otpdb');

$con = mysqli_connect(HOST,USER,PASS,DB) or die('Unable to Connect');

?>
