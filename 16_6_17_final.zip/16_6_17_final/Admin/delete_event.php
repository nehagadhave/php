<?php
include("db_connect.php");
$event_id=$_REQUEST['event_id'];
echo $event_id;
	$query="delete from event_reg where event_id='$event_id'";
	$query1 = $con->query($query);




header("Location: validate_event.php");
?>
