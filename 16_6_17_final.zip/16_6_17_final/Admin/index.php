<?php
session_start();
if( isset( $_SESSION['ad_email'] ) ) 
{
$email=$_SESSION['ad_email'];
?>

<!DOCTYPE html>
<html>
<head>
<title>Admin-PETSHOP</title>
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<!-- Bootstrap -->
<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css">

<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="js/jquery.min.js"></script>

<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Tangerine">
<!--------------------------For Modal------------------------->
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<!--------------------------End Of For Modal------------------------->




<!-- Custom Theme files -->
<!--theme-style-->
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />	
<!--//theme-style-->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Sport Responsive web template, Bootstrap Web Templates, Flat Web Templates, Andriod Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyErricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>

<!-- Font Awesome -->
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">


<!--fonts-->
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800' rel='stylesheet' type='text/css'>
<!--//fonts-->

</head>
<body> 
<!--header-->
	<div class="line">
	
	</div>
	<div class="header">
		<div class="logo">
			<a href="#"><img src="images/small_logo.png" alt="" ></a>
		</div>
		<div  class="header-top">
			<div class="header-grid">
				<ul class="header-in">
                                        <?php if (!isset($_SESSION['ad_email'])){ 
                                         ?>                                       
                                               	<li ><a href="login.php">Login</a> </li>
                                          
					<?php
                                          }else{
                                           
                                         ?>

					<li><a href="logout.php" >Logout</a></li>
                                        <?php } ?> 
				
					</ul>

					
					<div class="online">

                                        <a href="#" ></a>

					</div> 
					<div class="clearfix"> </div> 
			</div>
			<div class="header-bottom">
				<div class="h_menu4"><!-- start h_menu4 -->
				<a class="toggleMenu" href="#">Menu</a>
				<ul class="nav">
					<li class="active"><a href="index.php">Home</a></li>
					<li><a href="validate_ad.php">Manage Post</a></li>
					<li><a href="validate_event.php">Manage Event </a></li>
                                        <li><a href="validate_hospital.php">Manage Care Center </a></li>
					<li><a href="validate_hostel.php">Manage Hostels</a></li>
                                        <li><a href="user_query.php">User Query</a></li>			 
				</ul>
				<script type="text/javascript" src="js/nav.js"></script>
			</div><!-- end h_menu4 -->
					<ul class="header-bottom-in">
							
					</ul>
			<div class="clearfix"> </div>
		</div>
		</div>
		<div class="clearfix"> </div>
	</div>
	<!---->
	<div class="banner">
	<div class="container">
		<div class="banner-matter">
			<h1>PETSHOP</h1>
			
		</div>	
		</div>
	</div>
<!---->
<div class="content">
	<div class="sport-your">
<!-- requried-jsfiles-for owl -->
							<link href="css/owl.carousel.css" rel="stylesheet">
							    <script src="js/owl.carousel.js"></script>
							        <script>
									    $(document).ready(function() {
									      $("#owl-demo").owlCarousel({
									        items : 5,
									        lazyLoad : true,
									        autoPlay : true,
									        navigation : true,
									        navigationText :  true,
									        pagination : false,
									      });
									    });
									  </script>
<div class="line1">
	
		</div>
		<div id="example1">
		<div id="owl-demo" class="owl-carousel text-center">
			<div class="item">
					<img class="img-responsive " src="images/1.jpg" alt="">
				<div class="run">
					
					<p>Dogs</p>
				</div>
				</a>
			</div>
			<div class="item">
					<img class="img-responsive " src="images/2.jpg" alt="">
				<div class="run">
					
					<p>Birds</p>
				</div>
				</a>
			</div>
			<div class="item">
					<img class="img-responsive " src="images/3.jpg" alt="">
				<div class="run">
				
				<p>Cats</p>
				</div>
				</a>
			</div>
			<div class="item">
					<img class="img-responsive " src="images/4.jpg" alt="">
				<div class="run">
				
				<p>Aquarium</p>
				</div>
				</a>
			</div>
			<div class="item">
					<img class="img-responsive " src="images/1.jpg" alt="">
				<div class="run">
				
				<p>Dogs</p>
				</div>
				</a>
			</div> 
			<div class="item">
					<img class="img-responsive " src="images/2.jpg" alt="">
				<div class="run">
				
				<p>Cats</p>
				</div>
				</a>
			</div>
			<div class="item">
					<img class="img-responsive " src="images/3.jpg" alt="">
				<div class="run">
					<p>Birds</p>
				</div>
				</a>
			</div>
			<div class="item">
					<img class="img-responsive " src="images/4.jpg" alt="">
				<div class="run">
				
				<p>Aquarium</p>
				</div>
				</a>
			</div>
			<div class="item">
					<img class="img-responsive " src="images/1.jpg" alt="">
				<div class="run">
				
				<p>Dogs</p>
				</div>
				</a>
			</div>
			<div class="item">
					<img class="img-responsive " src="images/2.jpg" alt="">
				<div class="run">
				
				<p>Cats</p>
				</div>
				</a>
			</div>
			<div class="item">
					<img class="img-responsive " src="images/3.jpg" alt="">
				<div class="run">
				
				<p>Birds</p>
				</div>
				</a>
			</div>
		</div>
		</div>
		<h6 class="your-in">Your Pets</h6>
		<div class="line2">
	         
		</div>
                <br><center><p1></p1></center>

	</div>
		
	<div class="content-top">
		
		<div class="clearfix"> </div>
	</div> 
	<div class="content-bottom">
		
<!--footer-->
	<div class="footer">
		
</body>
</html>
<?php
}
else
header("Location: login.php");
?>

