<?php
include("db_connect.php");
session_start();
$message="";
$email=$_POST['email'];
$password=$_POST['password'];
//$encrypt_pass=md5($password);
$msg='';
if(!empty($_POST['Login'])) 
{
/*$ans="SELECT * FROM admin WHERE email='$email' and password = '$password'";
	$result = $con->query($ans); */

	if($email=='ranou.petshop@gmail.com' && $password=='a123')

	//if(mysqli_num_rows($result)>0)	
	{	
	$_SESSION['ad_email'] = $_POST['email'];
        $msg= "\nLogin successful";
        header("Location: index.php");
   
         }
        else
         $msg= "Invalid Username or Password";
         include('login.php');
}

?>
