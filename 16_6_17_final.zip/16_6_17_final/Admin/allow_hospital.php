<?php
include("db_connect.php");

$con = mysqli_connect(HOST,USER,PASS,DB) or die('Unable to Connect');
 
$id=$_REQUEST['id'];

	$query="update petcare_reg set active='1' where id='$id'";
	$query = $con->query($query);


$query_1="select email from petcare_reg where id='$id'";

$ans=$con->query($query_1);

   while($row = $ans->fetch_assoc())
  {

$email_1=$row["email"];

      $to      = $email_1; // Send email to our user
      $subject = 'PETSHOP | Pet Hostel Verified'; // Give the email a subject 
      $message = 'WEL-COME To PETSHOP
Your request for registration of pet hospital is verified.
Thank You.                  '; // Our message above including the link
                     
	$headers = 'From:ranou.petshop@gmail.com' . "\r\n"; // Set from headers

	$result =  mail($to, $subject, $message, $headers); // Send our email

  }


      

header("Location: validate_hospital.php");
?>
