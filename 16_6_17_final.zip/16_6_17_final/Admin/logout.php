<?php

  session_start();
  unset($_SESSION['ad_email']);
 header('Location: index.php');

 ?>

