<?php
include("db_connect.php");
session_start();
if( isset( $_SESSION['ad_email'] ) ) 
{
$email=$_SESSION['ad_email'];

$query="select ename,catagory,date,place,event_id from event_reg where date >= CURDATE() and active=0";
$ans=$con->query($query);
 
$n=mysqli_num_rows($ans);

?>

<!DOCTYPE html>
<html>
<head>
<META HTTP-EQUIV="refresh" CONTENT="100">
<title>PETSHOP</title>
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<!-- Bootstrap -->
<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css">

<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="js/jquery.min.js"></script>

<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Tangerine">
<!--------------------------For Modal------------------------->
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<!--------------------------End Of For Modal------------------------->




<!-- Custom Theme files -->
<!--theme-style-->
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />	
<!--//theme-style-->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Sport Responsive web template, Bootstrap Web Templates, Flat Web Templates, Andriod Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyErricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>

<!-- Font Awesome -->
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">


<!--fonts-->
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800' rel='stylesheet' type='text/css'>
<!--//fonts-->

</head>
<body> 
<!--header-->
	<div class="line">
	
	</div>
	<div class="header">
		<div class="logo">
			<a href="#"><img src="images/small_logo.png" alt="" ></a>
		</div>
		<div  class="header-top">
			<div class="header-grid">
				<ul class="header-in">
                                        <?php if (!isset($_SESSION['ad_email'])){ 
                                         ?>                                       
                                               	<li ><a href="login.php">Login</a> </li>
                                          
					<?php
                                          }else{
                                           
                                         ?>

					<li><a href="logout.php" >Logout</a></li>
                                        <?php } ?> 
				
					</ul>

					
					<div class="online">

                                        <a href="#" ></a>

					</div> 
					<div class="clearfix"> </div> 
			</div>
			<div class="header-bottom">
				<div class="h_menu4"><!-- start h_menu4 -->
				<a class="toggleMenu" href="#">Menu</a>
				<ul class="nav">
					<li class="active"><a href="index.php">Home</a></li>
					<li><a href="validate_ad.php">Manage Post</a></li>
					<li><a href="validate_event.php">Manage Event </a></li>
                                        <li><a href="validate_hospital.php">Manage Care Center </a></li>
					<li><a href="validate_hostel.php">Manage Hostels</a></li>
					<li><a href="user_query.php">User Query</a></li>				 
				</ul>
				<script type="text/javascript" src="js/nav.js"></script>
			</div><!-- end h_menu4 -->
			
					<ul class="header-bottom-in">
							
					</ul>
			<div class="clearfix"> </div>
		</div>
		</div>
		<div class="clearfix"> </div>
	</div>

<!---->
<div class="container">
		<div class="register">
		<p1><center>Events</center></p1>		
		<div class=" register-top" >
                <div class="bs-example">
                <table class="table table-hover">
<?php
if($n==0)
echo "<center><h3><error>No Record Found...</error></h3></center>";

else
{

?>
                <thead>
                <tr>
                <th>Event Name</th>
                <th>Catagory</th>
                <th>Date</th>
                <th>Place</th>

                </tr>
               </thead>
              <tbody>
		<?php


  while($row = $ans->fetch_assoc())
  {
   $ename=$row["ename"];
   $catagory=$row["catagory"];
   $date=$row["date"];
   $place=$row["place"];
   $event_id=$row["event_id"];
?>

            <tr>
                <td><?php echo $ename ?></td>
                <td><?php echo $catagory ?></td>
                <td><?php echo $date ?></td>
                <td><?php echo $place ?></td>
		<td><a href="allow_event.php?event_id=<?php echo $event_id?>" data-toggle="tooltip" title="Allow!"><i class="fa fa-check" aria-hidden="true" style="font-size:20px;color:green;"></i></a></td>
		<td><a href="delete_event.php?event_id=<?php echo $event_id?>" data-toggle="tooltip" title="Delete"><i class="fa fa-trash-o" aria-hidden="true" style="font-size:20px;color:red;"></i></a></td>
            </tr>


<?php
}
}
$con->close();
?>

        </tbody>
    </table>
</div>
	
		</div>		
	</div>
	</div>

	<!---->
<!--footer-->
	<div class="footer">
</div>		

</body>
</html>
<?php
}
?>
