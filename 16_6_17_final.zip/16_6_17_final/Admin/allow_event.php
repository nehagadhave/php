<?php
include("db_connect.php");
$event_id=$_REQUEST['event_id'];
echo $event_id;
	$query="update event_reg set active='1' where event_id='$event_id'";
	$query = $con->query($query);

$query1="select ename,date,place,event_id,time,owner_contact,owner_email from event_reg where date >= CURDATE() and active=1 and event_id='$event_id'";
 
 $ans1=$con->query($query1);
 
  while($row = $ans1->fetch_assoc())
  {
   $ename=$row["ename"];
   $date=$row["date"];
   $place=$row["place"];
   $event_id=$row["event_id"];
   $time=$row["time"];
   $owner_contact=$row['owner_contact'];
   $owner_email=$row['owner_email'];

//Send the Verification Email
$query2="select email from user where active=1";
 
$ans2=$con->query($query2);
$recipients = array();
 
  while($row = $ans2->fetch_assoc())
  {
   $recipients[] = $row['email'];
  }
	$to      = implode(', ', $recipients) . "\r\n"; // Send email to our user
	$subject = 'PETSHOP|'.$ename.' Invitition'; // Give the email a subject 
	$message = 'We are happy to invite you for the new Pet Event i.e. '.$ename.' which is going to held on
                    Date      : '.$date.'
                    Place     : '.$place.'
                    Time      : '.$time.'
                    Contact   : '.$owner_contact.'
                    Email     : '.$owner_email.'
 
                
		For more details please login to your account:
		http://ranou.esy.es/PETSHOP/login.php
		Thank you.'; // Our message above including the link
                     
	$headers = 'From:ranou.petshop@gmail.com' . "\r\n"; // Set from headers

	$result =  mail($to, $subject, $message, $headers); // Send our email
  }      

	$query3="select owner_email from event_reg where event_id='$event_id'";
	$ans3 = $con->query($query3);

	  while($row = $ans3->fetch_assoc())
	  {
	   $owner_email=$row["owner_email"];

	$to      = $owner_email; // Send email to our user
	$subject = 'PETSHOP|'.$ename.' Verified'; // Give the email a subject 
	$message = 'We are happy to inform you that your Pet Event i.e. '.$ename.' is verified and is going to held on
                    Date      : '.$date.'
                    Place     : '.$place.'
                    Time      : '.$time.'
                    Contact   : '.$owner_contact.'
                    Email     : '.$owner_email.'

		For more details please login to your account:
		http://ranou.esy.es/PETSHOP/login.php
		Thank you.'; // Our message above including the link
                     
	$headers = 'From:ranou.petshop@gmail.com' . "\r\n"; // Set from headers

	$result =  mail($to, $subject, $message, $headers); // Send our email
	}

header("Location: validate_event.php");
?>
