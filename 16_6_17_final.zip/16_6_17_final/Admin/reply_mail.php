<?php

       include("db_connect.php");

$to=$_POST['to'];

$msg=$_POST['reply'];

$headers = 'From:ranou.petshop@gmail.com'; // Set from headers

$subject = 'Reply To Your Query'; // Give the email a subject
$result =  mail($to, $subject, $msg, $headers); // Send our email

$update=$con->query("UPDATE comment SET flag='1' WHERE email='".$to."'AND flag='0'");

header("Location: user_query.php");

?>
