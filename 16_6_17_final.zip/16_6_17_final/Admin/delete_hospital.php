<?php
include("db_connect.php");
$con = mysqli_connect(HOST,USER,PASS,DB) or die('Unable to Connect');
 
$id=$_REQUEST['id'];

	$query="delete from petcare_reg where id='$id'";
	$query1 = $con->query($query);


header("Location: validate_hospital.php");
?>
