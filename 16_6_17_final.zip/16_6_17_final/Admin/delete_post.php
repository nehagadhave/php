<?php
include("db_connect.php");
$con = mysqli_connect(HOST,USER,PASS,DB) or die('Unable to Connect');
 
$s_id=$_REQUEST['s_id'];

	$query="delete from pet where s_id='$s_id'";
	$query1 = $con->query($query);


header("Location: validate_ad.php");
?>
