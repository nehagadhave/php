<?php
include("db_connect.php");
 
$s_id=$_REQUEST['s_id'];

	$query="update pet set active='1' where s_id='$s_id'";
	$query = $con->query($query);

$query_1="select email from pet where s_id='$s_id'";

$ans=$con->query($query_1);

  while($row = $ans->fetch_assoc())
   {

$email_1=$row["email"];

      $to      = $email_1; // Send email to our user
	$subject = 'PETSHOP | Ad is Acitivated'; // Give the email a subject 
	$message = 'WEL-COME To PETSHOP
Your Ad is Acitivated sucessfully..
Thank You'; // Our message above including the link
                     
	$headers = 'From:ranou.petshop@gmail.com' . "\r\n"; // Set from headers

	$result =  mail($to, $subject, $message, $headers); // Send our email

  }

header("Location: validate_ad.php");
?>
